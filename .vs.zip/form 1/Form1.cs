using System.Security.Cryptography;

namespace form_1
{
    public partial class Form1 : Form
    {
     

        // Arrays
        string[] playerOneData = new string[3];
        string[] playerTwoData = new string[3];

        int[] playerOneStats = new int[4];
        int[] playerTwoStats = new int[4];

        Random random = new Random();

        // Fire Dragon
        const int FIRE_DRAG_HP = 20;
        const int FIRE_DRAG_ATK = 5;
        const int FIRE_DRAG_SPATK = 12;
        const int FIRE_DRAG_BLOCK = 4;

        // Ice Dragon
        const int ICE_DRAG_HP = 30;
        const int ICE_DRAG_ATK = 4;
        const int ICE_DRAG_SPATK = 9;
        const int ICE_DRAG_BLOCK = 5;

        // Earth Dragon
        const int EARTH_DRAG_HP = 50;
        const int EARTH_DRAG_ATK = 2;
        const int EARTH_DRAG_SPATK = 5;
        const int EARTH_DRAG_BLOCK = 6;

        // Wind Dragon
        const int WIND_DRAG_HP = 40;
        const int WIND_DRAG_ATK = 3;
        const int WIND_DRAG_SPATK = 7;
        const int WIND_DRAG_BLOCK = 5;

        // Save Booleans
        bool playerOneSaved = false;
        bool playerTwoSaved = false;




        public Form1(string[] p1Data, string[] p2Data, int[] p1Stats, int[] p2stats,int starter )
        {
            InitializeComponent();
            playerOneData = p1Data;
            playerTwoData = p2Data;

            playerOneStats = p1Stats;
            playerTwoStats = p2stats;

           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private int randomRoll()
        {
            return random.Next(1, 7);
        }

        private int takeInitiative()
        {
            int player1Roll;
            int player2Roll;


            do
            {
                player1Roll = randomRoll();
                player2Roll = randomRoll();

            }
            while (player1Roll == player2Roll);

            if (player1Roll > player2Roll)
            {
                return 1;
            }
            else
            {
                return 2;
            }
        }




        private void Form1_Load(object sender, EventArgs e)
        {
            stbttn1.Enabled = false;
        }
        private void saveValues(string playerName, string dragonName, string dragonType, string[] playerData, int[] playerStats)
        {
            playerData[0] = playerName;
            playerData[1] = dragonName;
            playerData[2] = dragonType;

            switch (dragonType)
            {
                case "Fire Dragon":

                    playerStats[0] = FIRE_DRAG_HP;
                    playerStats[1] = FIRE_DRAG_ATK;
                    playerStats[2] = FIRE_DRAG_SPATK;
                    playerStats[3] = FIRE_DRAG_BLOCK;

                    break;

                case "Ice Dragon":

                    playerStats[0] = ICE_DRAG_HP;
                    playerStats[1] = ICE_DRAG_ATK;
                    playerStats[2] = ICE_DRAG_SPATK;
                    playerStats[3] = ICE_DRAG_BLOCK;

                    break;

                case "Earth Dragon":

                    playerStats[0] = EARTH_DRAG_HP;
                    playerStats[1] = EARTH_DRAG_ATK;
                    playerStats[2] = EARTH_DRAG_SPATK;
                    playerStats[3] = EARTH_DRAG_BLOCK;

                    break;

                case "Wind Dragon":

                    playerStats[0] = WIND_DRAG_HP;
                    playerStats[1] = WIND_DRAG_ATK;
                    playerStats[2] = WIND_DRAG_SPATK;
                    playerStats[3] = WIND_DRAG_BLOCK;

                    break;

            }
        }













        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void player1groupbox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Player1firebtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Player1icebtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Player1earthbtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Player1windbtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void player1save_Click(object sender, EventArgs e)
        {
            string dragonType = "";

            if (Player1firebtn.Checked)
            {
                dragonType = "Fire Dragon";
            }
            else if (Player1icebtn.Checked)
            {
                dragonType = "Ice Dragon";
            }
            else if (Player1earthbtn.Checked)
            {
                dragonType = "Earth Dragon";
            }
            else if (Player1windbtn.Checked)
            {
                dragonType = "Wind Dragon";
            }

            saveValues(textBox1.Text, textBox2.Text,
               dragonType, playerOneData, playerOneStats);

            playerOneSaved = true;

            MessageBox.Show("Player 1 Saved!");

            if (playerOneSaved && playerTwoSaved)
            {
                stbttn1.Enabled = true;
            }
        }

        

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            String dragonType = "";

            if (player2fireBttn.Checked)
            {
                dragonType = "Fire Dragon";
            }
            else if (player2Icebttn.Checked)
            {
                dragonType = "Ice Dragon";

            }
            else if (player2Earthbtn.Checked)
            {
                dragonType = "Earth Dragon";
            }
            else if (player2windbtn.Checked)
            {
                dragonType = "Wind Dragon";
            }

            saveValues(textBox3.Text, textBox4.Text, dragonType, playerTwoData, playerTwoStats);

            playerOneSaved = true;

            MessageBox.Show("Player 1 Saved!");

            if (playerOneSaved && playerTwoSaved)
            {
                stbttn1.Enabled = true;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void player2groupbox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void player2fireBttn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void player2Icebttn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void player2Earthbtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void player2windbtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void stbttn1_Click(object sender, EventArgs e)
        {
            int starter = takeInitiative();

            Form1 battleForm = new  Form1(playerOneData, playerTwoData, playerOneStats, playerTwoStats, starter);


            battleForm.Show();
            this.Hide();
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
