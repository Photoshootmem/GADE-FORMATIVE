﻿namespace form_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lBlplayer1 = new Label();
            Dr1 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            player1groupbox = new RadioButton();
            Player1firebtn = new RadioButton();
            Player1icebtn = new RadioButton();
            Player1windbtn = new RadioButton();
            Player1earthbtn = new RadioButton();
            player1save = new Button();
            lblplayer2 = new Label();
            Dr2 = new Label();
            player2save = new Button();
            player2groupbox = new RadioButton();
            player2fireBttn = new RadioButton();
            player2Icebttn = new RadioButton();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            player2windbtn = new RadioButton();
            player2Earthbtn = new RadioButton();
            stbttn1 = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // lBlplayer1
            // 
            lBlplayer1.AutoSize = true;
            lBlplayer1.Location = new Point(157, 53);
            lBlplayer1.Name = "lBlplayer1";
            lBlplayer1.Size = new Size(75, 15);
            lBlplayer1.TabIndex = 0;
            lBlplayer1.Text = "Player name ";
            lBlplayer1.Click += label1_Click;
            // 
            // Dr1
            // 
            Dr1.AutoSize = true;
            Dr1.Location = new Point(158, 100);
            Dr1.Name = "Dr1";
            Dr1.Size = new Size(82, 15);
            Dr1.TabIndex = 1;
            Dr1.Text = "Dragon name ";
            Dr1.Click += label2_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(245, 50);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 2;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.Turquoise;
            textBox2.Location = new Point(245, 97);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 3;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // player1groupbox
            // 
            player1groupbox.Location = new Point(158, 158);
            player1groupbox.Name = "player1groupbox";
            player1groupbox.Size = new Size(104, 26);
            player1groupbox.TabIndex = 5;
            player1groupbox.TabStop = true;
            player1groupbox.Text = "select Dragon";
            player1groupbox.UseVisualStyleBackColor = true;
            player1groupbox.CheckedChanged += player1groupbox_CheckedChanged;
            // 
            // Player1firebtn
            // 
            Player1firebtn.Appearance = Appearance.Button;
            Player1firebtn.AutoSize = true;
            Player1firebtn.Location = new Point(161, 204);
            Player1firebtn.Name = "Player1firebtn";
            Player1firebtn.Size = new Size(78, 25);
            Player1firebtn.TabIndex = 6;
            Player1firebtn.TabStop = true;
            Player1firebtn.Text = "Fire Dragon";
            Player1firebtn.UseVisualStyleBackColor = true;
            Player1firebtn.CheckedChanged += Player1firebtn_CheckedChanged;
            // 
            // Player1icebtn
            // 
            Player1icebtn.Appearance = Appearance.Button;
            Player1icebtn.AutoSize = true;
            Player1icebtn.Location = new Point(161, 235);
            Player1icebtn.Name = "Player1icebtn";
            Player1icebtn.Size = new Size(74, 25);
            Player1icebtn.TabIndex = 7;
            Player1icebtn.TabStop = true;
            Player1icebtn.Text = "Ice Dragon";
            Player1icebtn.UseVisualStyleBackColor = true;
            Player1icebtn.CheckedChanged += Player1icebtn_CheckedChanged;
            // 
            // Player1windbtn
            // 
            Player1windbtn.Appearance = Appearance.Button;
            Player1windbtn.AutoSize = true;
            Player1windbtn.Location = new Point(161, 297);
            Player1windbtn.Name = "Player1windbtn";
            Player1windbtn.Size = new Size(87, 25);
            Player1windbtn.TabIndex = 8;
            Player1windbtn.TabStop = true;
            Player1windbtn.Text = "Wind Dragon";
            Player1windbtn.UseVisualStyleBackColor = true;
            Player1windbtn.CheckedChanged += Player1windbtn_CheckedChanged;
            // 
            // Player1earthbtn
            // 
            Player1earthbtn.Appearance = Appearance.Button;
            Player1earthbtn.AutoSize = true;
            Player1earthbtn.Location = new Point(161, 266);
            Player1earthbtn.Name = "Player1earthbtn";
            Player1earthbtn.Size = new Size(86, 25);
            Player1earthbtn.TabIndex = 9;
            Player1earthbtn.TabStop = true;
            Player1earthbtn.Text = "Earth Dragon";
            Player1earthbtn.UseVisualStyleBackColor = true;
            Player1earthbtn.CheckedChanged += Player1earthbtn_CheckedChanged;
            // 
            // player1save
            // 
            player1save.Location = new Point(158, 363);
            player1save.Name = "player1save";
            player1save.Size = new Size(104, 23);
            player1save.TabIndex = 10;
            player1save.Text = "save";
            player1save.UseVisualStyleBackColor = true;
            player1save.Click += player1save_Click;
            // 
            // lblplayer2
            // 
            lblplayer2.AutoSize = true;
            lblplayer2.Location = new Point(471, 53);
            lblplayer2.Name = "lblplayer2";
            lblplayer2.Size = new Size(81, 15);
            lblplayer2.TabIndex = 11;
            lblplayer2.Text = "Player name 2";
            // 
            // Dr2
            // 
            Dr2.AutoSize = true;
            Dr2.Location = new Point(471, 105);
            Dr2.Name = "Dr2";
            Dr2.Size = new Size(88, 15);
            Dr2.TabIndex = 12;
            Dr2.Text = "Dragon name 2";
            // 
            // player2save
            // 
            player2save.Location = new Point(589, 363);
            player2save.Name = "player2save";
            player2save.Size = new Size(93, 23);
            player2save.TabIndex = 14;
            player2save.Text = "save";
            player2save.UseVisualStyleBackColor = true;
            player2save.Click += button2_Click;
            // 
            // player2groupbox
            // 
            player2groupbox.Location = new Point(578, 158);
            player2groupbox.Name = "player2groupbox";
            player2groupbox.Size = new Size(104, 31);
            player2groupbox.TabIndex = 15;
            player2groupbox.TabStop = true;
            player2groupbox.Text = "select Dragon";
            player2groupbox.UseVisualStyleBackColor = true;
            player2groupbox.CheckedChanged += player2groupbox_CheckedChanged;
            // 
            // player2fireBttn
            // 
            player2fireBttn.Appearance = Appearance.Button;
            player2fireBttn.AutoSize = true;
            player2fireBttn.Location = new Point(579, 195);
            player2fireBttn.Name = "player2fireBttn";
            player2fireBttn.Size = new Size(78, 25);
            player2fireBttn.TabIndex = 16;
            player2fireBttn.TabStop = true;
            player2fireBttn.Text = "Fire Dragon";
            player2fireBttn.UseVisualStyleBackColor = true;
            player2fireBttn.CheckedChanged += player2fireBttn_CheckedChanged;
            // 
            // player2Icebttn
            // 
            player2Icebttn.Appearance = Appearance.Button;
            player2Icebttn.AutoSize = true;
            player2Icebttn.Location = new Point(578, 226);
            player2Icebttn.Name = "player2Icebttn";
            player2Icebttn.Size = new Size(74, 25);
            player2Icebttn.TabIndex = 17;
            player2Icebttn.TabStop = true;
            player2Icebttn.Text = "Ice Dragon";
            player2Icebttn.UseVisualStyleBackColor = true;
            player2Icebttn.CheckedChanged += player2Icebttn_CheckedChanged;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(582, 53);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 18;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.Turquoise;
            textBox4.Location = new Point(579, 97);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(100, 23);
            textBox4.TabIndex = 19;
            textBox4.TextChanged += textBox4_TextChanged;
            // 
            // player2windbtn
            // 
            player2windbtn.Appearance = Appearance.Button;
            player2windbtn.AutoSize = true;
            player2windbtn.Location = new Point(577, 288);
            player2windbtn.Name = "player2windbtn";
            player2windbtn.Size = new Size(87, 25);
            player2windbtn.TabIndex = 21;
            player2windbtn.TabStop = true;
            player2windbtn.Text = "Wind Dragon";
            player2windbtn.UseVisualStyleBackColor = true;
            player2windbtn.CheckedChanged += player2windbtn_CheckedChanged;
            // 
            // player2Earthbtn
            // 
            player2Earthbtn.Appearance = Appearance.Button;
            player2Earthbtn.AutoSize = true;
            player2Earthbtn.BackColor = SystemColors.Control;
            player2Earthbtn.Location = new Point(578, 257);
            player2Earthbtn.Name = "player2Earthbtn";
            player2Earthbtn.Size = new Size(86, 25);
            player2Earthbtn.TabIndex = 23;
            player2Earthbtn.TabStop = true;
            player2Earthbtn.Text = "Earth Dragon";
            player2Earthbtn.UseVisualStyleBackColor = false;
            player2Earthbtn.CheckedChanged += player2Earthbtn_CheckedChanged;
            // 
            // stbttn1
            // 
            stbttn1.Location = new Point(377, 363);
            stbttn1.Name = "stbttn1";
            stbttn1.Size = new Size(75, 23);
            stbttn1.TabIndex = 24;
            stbttn1.Text = "Start game";
            stbttn1.UseVisualStyleBackColor = true;
            stbttn1.Click += stbttn1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(43, 48);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 25;
            label1.Text = "label1";
            label1.Click += label1_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Red;
            BackgroundImage = Properties.Resources.ChatGPT_Image_May_15__2026__02_36_25_PM;
            BackgroundImageLayout = ImageLayout.Center;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(stbttn1);
            Controls.Add(player2Earthbtn);
            Controls.Add(player2windbtn);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(player2Icebttn);
            Controls.Add(player2fireBttn);
            Controls.Add(player2groupbox);
            Controls.Add(player2save);
            Controls.Add(Dr2);
            Controls.Add(lblplayer2);
            Controls.Add(player1save);
            Controls.Add(Player1earthbtn);
            Controls.Add(Player1windbtn);
            Controls.Add(Player1icebtn);
            Controls.Add(Player1firebtn);
            Controls.Add(player1groupbox);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(Dr1);
            Controls.Add(lBlplayer1);
            Name = "Form1";
            Text = "/";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lBlplayer1;
        private Label Dr1;
        private TextBox textBox1;
        private TextBox textBox2;
        private RadioButton player1groupbox;
        private RadioButton Player1firebtn;
        private RadioButton Player1icebtn;
        private RadioButton Player1windbtn;
        private RadioButton Player1earthbtn;
        private Button player1save;
        private Label lblplayer2;
        private Label Dr2;
        private Button player2save;
        private RadioButton player2groupbox;
        private RadioButton player2fireBttn;
        private RadioButton player2Icebttn;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private RadioButton player2windbtn;
        private TextBox textBox6;
        private RadioButton player2Earthbtn;
        private Button stbttn1;
        private Label label1;
    }
}
