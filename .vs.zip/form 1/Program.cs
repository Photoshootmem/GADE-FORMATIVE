namespace form_1
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            string[] p1Data = new string[3];
            string[] p2Data = new string[3];

            int[] p1Stats = new int[4];
            int[] p2Stats = new int[4];

            int starter = 1;

        }
    }
}